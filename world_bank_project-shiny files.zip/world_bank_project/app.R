library(pacman)

pacman::p_load(readr, dplyr, tidyverse, data.table, knitr, lmtest, lubridate, ggplot2, gridExtra, shiny, sf, ggmap, maps, cowplot)

library(mapdata)

wide_narm <- fread("wide_narm.csv")

if(!is.data.table(wide_narm)){wide_narm <- data.table(wide_narm)}

wide_narm$country <- as.factor(wide_narm$country)

df <- subset(wide_narm, select = -country)

world_map <- map_data("world")

prelim_df1 <- fread("prelim_df1.csv")

lm_prelim1 <- lm(prelim_df1$gnipc_constant ~., data = prelim_df1)

melted_corr_mat <- fread("melted_corr_mat.csv")

#world_map <- left_join( world_map, wb_countries, by = c('region' = 'country')) 

# Group data by decade
df_decade <- df %>%
  mutate(decade = 10 * floor(year / 10))

ui <- fluidPage(
  
  fluidRow(
        titlePanel(
          h1("World Bank Project"
          ))
  ),
  fluidRow(
    titlePanel(h3("Group: Nick McCulloch, Cody Meagher, Stefano Mesetti"
    ))
  ),
  
  hr(),
  
  fluidRow(
    titlePanel(
      h3("Dataset Limitations"
      )),
    #sidebarLayout(
    #sidebarPanel(),
    #mainPanel(
      img(src="gif.gif", align = "left",height='450px',width='900px')
  #),
    #)
  ),
  
  fluidRow(
    sidebarLayout(
    sidebarPanel(
      numericInput("residual_var",
                   "Residual/Multicollinearity Plots:", min = 1, max = 6, value = 1, step = 1)),
    mainPanel(
      plotOutput("residual_plot")
    ),
    )
  ),
  
  hr(),
  
  fluidRow(
    titlePanel(
      h3("Interpretation"
      )),
  ),
  
  fluidRow(
    sidebarLayout(
      sidebarPanel(
        sliderInput(
          "decade_slider",
          "Decade:",
          min = 1960,
          max = 2020,
          value = 2010,
          step = 10
        ),
        
        varSelectInput("scatter_varX","select x variable",df, selected = "literacy_at"),
        varSelectInput("scatter_varY","select y variable",df, selected = "gnipc_constant"),
        checkboxInput("smooth", "Add Regression Line", value = FALSE),
        sliderInput(
          "y_lim_slider",
          "Max Income:",
          min = 1000,
          max = 200000,
          value = 75000,
          step = 1000
        ),
      ),
      mainPanel(
        plotOutput("scatter_plot")
      ))
  ),
  
  hr(),
  
  fluidRow(
    titlePanel("GNI and GDP Analysis"),
    
    sidebarLayout(
      sidebarPanel(
        selectInput("country", 
                    label = "Choose a country",
                    choices = unique(wide_narm$country),
                    selected = "South Africa"
        )
      ),
      
      mainPanel(
        tabsetPanel(type = "tabs",
                    tabPanel("GNI and GDP Over Time", 
                             plotOutput("timePlot"),
                             plotOutput("countryplot"))
        )
      )
    )
  ),
  fluidRow(
    
  ),
  fluidRow(
  )
)

server <- function(input, output) {
  output$residual_plot <- renderPlot({
    if(input$residual_var < 6) {
      plot(lm_prelim1, which = input$residual_var)
    } else {
      ggplot(data = melted_corr_mat, aes(x = Var1,  y = Var2, fill = value)) +
        geom_tile() + labs(title = "Correlation Heatmap")+
        theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
    }
  })
  
  filtered_data <- reactive({
    df_decade[df_decade$decade == input$decade_slider,]
  })
  
  output$scatter_plot <- renderPlot({
    ggplot(filtered_data(), aes(
      x = !!input$scatter_varX, 
      y = !!input$scatter_varY)) +
      geom_point() +
      ggtitle("Scatter Plot (Grouped by Decade)") +
      xlim(0, 100) + ylim(0, input$y_lim_slider) +
      theme_minimal() +
      if(input$smooth) {geom_smooth()}
  })
  
  currentData <- reactive({input$country
  })
  
  output$timePlot <- renderPlot({
    data <- wide_narm[wide_narm$country == input$country, ]
    
    gdp <- ggplot(data, aes(x = year, y = gdppc_constant)) +
      geom_line() +
      ggtitle(paste("GDP per capita Over Time for", input$country)) +
      ylab("GDP") + xlab("Year")
    
    gni <- ggplot(data, aes(x = year, y = gnipc_constant)) +
      geom_line() +
      ggtitle(paste("GNI per capita Over Time for", input$country)) +
      ylab("GNI") + xlab("Year")
    
    world_plot <- ggplot() +
      geom_polygon(data = world_map, aes(x = long, y = lat, group = group),
                   fill = ifelse(world_map$region == input$country, "red", "lightgray"),
                   color = "black") +
      coord_equal() +
      labs(title = "World Map") + xlab(NULL) + ylab(NULL) +
      theme_light()
    
    # Adjust plot size by specifying dimensions in plotOutput
    plot_grid(gdp, gni, world_plot, ncol = 1, rel_heights = c(2, 2, 3.5))
  }, height = 800)  # Specify desired height for the plot
  
  }


shinyApp(ui, server)